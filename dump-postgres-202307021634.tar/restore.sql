--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3
-- Dumped by pg_dump version 15.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Russian_Russia.1251';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Альбомы; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Альбомы" (
    id integer NOT NULL,
    "Название_альбома" character varying(90) NOT NULL,
    "Год_выпуска" integer NOT NULL
);


ALTER TABLE public."Альбомы" OWNER TO postgres;

--
-- Name: Альбомы_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Альбомы_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Альбомы_id_seq" OWNER TO postgres;

--
-- Name: Альбомы_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Альбомы_id_seq" OWNED BY public."Альбомы".id;


--
-- Name: Альбомы_и_исполнители; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Альбомы_и_исполнители" (
    "id_альбома" integer NOT NULL,
    "id_исполнителя" integer NOT NULL
);


ALTER TABLE public."Альбомы_и_исполнители" OWNER TO postgres;

--
-- Name: Жанры; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Жанры" (
    id integer NOT NULL,
    name_of_genre character varying(60) NOT NULL
);


ALTER TABLE public."Жанры" OWNER TO postgres;

--
-- Name: Жанры_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Жанры_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Жанры_id_seq" OWNER TO postgres;

--
-- Name: Жанры_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Жанры_id_seq" OWNED BY public."Жанры".id;


--
-- Name: Жанры_и_исполнители; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Жанры_и_исполнители" (
    "id_жанра" integer NOT NULL,
    "id_исполнителя" integer NOT NULL
);


ALTER TABLE public."Жанры_и_исполнители" OWNER TO postgres;

--
-- Name: Исполнители; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Исполнители" (
    id integer NOT NULL,
    name_of_artist character varying(60) NOT NULL
);


ALTER TABLE public."Исполнители" OWNER TO postgres;

--
-- Name: Исполнители_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Исполнители_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Исполнители_id_seq" OWNER TO postgres;

--
-- Name: Исполнители_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Исполнители_id_seq" OWNED BY public."Исполнители".id;


--
-- Name: Сборники; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Сборники" (
    id integer NOT NULL,
    "Название_сборника" character varying(60) NOT NULL,
    "Год_выпуска" integer NOT NULL
);


ALTER TABLE public."Сборники" OWNER TO postgres;

--
-- Name: Сборники_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Сборники_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Сборники_id_seq" OWNER TO postgres;

--
-- Name: Сборники_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Сборники_id_seq" OWNED BY public."Сборники".id;


--
-- Name: Треки; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Треки" (
    id integer NOT NULL,
    "Название_трека" character varying(90) NOT NULL,
    "Длительность" time without time zone NOT NULL,
    "id_альбома" integer
);


ALTER TABLE public."Треки" OWNER TO postgres;

--
-- Name: Треки_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Треки_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Треки_id_seq" OWNER TO postgres;

--
-- Name: Треки_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Треки_id_seq" OWNED BY public."Треки".id;


--
-- Name: Треки_в_сборнике; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Треки_в_сборнике" (
    "id_сборника" integer NOT NULL,
    "id_трека" integer NOT NULL
);


ALTER TABLE public."Треки_в_сборнике" OWNER TO postgres;

--
-- Name: Альбомы id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Альбомы" ALTER COLUMN id SET DEFAULT nextval('public."Альбомы_id_seq"'::regclass);


--
-- Name: Жанры id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Жанры" ALTER COLUMN id SET DEFAULT nextval('public."Жанры_id_seq"'::regclass);


--
-- Name: Исполнители id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Исполнители" ALTER COLUMN id SET DEFAULT nextval('public."Исполнители_id_seq"'::regclass);


--
-- Name: Сборники id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Сборники" ALTER COLUMN id SET DEFAULT nextval('public."Сборники_id_seq"'::regclass);


--
-- Name: Треки id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Треки" ALTER COLUMN id SET DEFAULT nextval('public."Треки_id_seq"'::regclass);


--
-- Data for Name: Альбомы; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Альбомы" (id, "Название_альбома", "Год_выпуска") FROM stdin;
\.
COPY public."Альбомы" (id, "Название_альбома", "Год_выпуска") FROM '$$PATH$$/3382.dat';

--
-- Data for Name: Альбомы_и_исполнители; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Альбомы_и_исполнители" ("id_альбома", "id_исполнителя") FROM stdin;
\.
COPY public."Альбомы_и_исполнители" ("id_альбома", "id_исполнителя") FROM '$$PATH$$/3383.dat';

--
-- Data for Name: Жанры; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Жанры" (id, name_of_genre) FROM stdin;
\.
COPY public."Жанры" (id, name_of_genre) FROM '$$PATH$$/3377.dat';

--
-- Data for Name: Жанры_и_исполнители; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Жанры_и_исполнители" ("id_жанра", "id_исполнителя") FROM stdin;
\.
COPY public."Жанры_и_исполнители" ("id_жанра", "id_исполнителя") FROM '$$PATH$$/3380.dat';

--
-- Data for Name: Исполнители; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Исполнители" (id, name_of_artist) FROM stdin;
\.
COPY public."Исполнители" (id, name_of_artist) FROM '$$PATH$$/3379.dat';

--
-- Data for Name: Сборники; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Сборники" (id, "Название_сборника", "Год_выпуска") FROM stdin;
\.
COPY public."Сборники" (id, "Название_сборника", "Год_выпуска") FROM '$$PATH$$/3385.dat';

--
-- Data for Name: Треки; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Треки" (id, "Название_трека", "Длительность", "id_альбома") FROM stdin;
\.
COPY public."Треки" (id, "Название_трека", "Длительность", "id_альбома") FROM '$$PATH$$/3387.dat';

--
-- Data for Name: Треки_в_сборнике; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Треки_в_сборнике" ("id_сборника", "id_трека") FROM stdin;
\.
COPY public."Треки_в_сборнике" ("id_сборника", "id_трека") FROM '$$PATH$$/3388.dat';

--
-- Name: Альбомы_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Альбомы_id_seq"', 4, true);


--
-- Name: Жанры_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Жанры_id_seq"', 6, true);


--
-- Name: Исполнители_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Исполнители_id_seq"', 4, true);


--
-- Name: Сборники_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Сборники_id_seq"', 4, true);


--
-- Name: Треки_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Треки_id_seq"', 8, true);


--
-- Name: Жанры_и_исполнители pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Жанры_и_исполнители"
    ADD CONSTRAINT pk PRIMARY KEY ("id_жанра", "id_исполнителя");


--
-- Name: Альбомы_и_исполнители pk2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Альбомы_и_исполнители"
    ADD CONSTRAINT pk2 PRIMARY KEY ("id_альбома", "id_исполнителя");


--
-- Name: Треки_в_сборнике pk3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Треки_в_сборнике"
    ADD CONSTRAINT pk3 PRIMARY KEY ("id_сборника", "id_трека");


--
-- Name: Альбомы Альбомы_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Альбомы"
    ADD CONSTRAINT "Альбомы_pkey" PRIMARY KEY (id);


--
-- Name: Жанры Жанры_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Жанры"
    ADD CONSTRAINT "Жанры_pkey" PRIMARY KEY (id);


--
-- Name: Исполнители Исполнители_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Исполнители"
    ADD CONSTRAINT "Исполнители_pkey" PRIMARY KEY (id);


--
-- Name: Сборники Сборники_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Сборники"
    ADD CONSTRAINT "Сборники_pkey" PRIMARY KEY (id);


--
-- Name: Треки Треки_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Треки"
    ADD CONSTRAINT "Треки_pkey" PRIMARY KEY (id);


--
-- Name: Альбомы_и_исполнители Альбомы_и_исполни_id_исполнителя_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Альбомы_и_исполнители"
    ADD CONSTRAINT "Альбомы_и_исполни_id_исполнителя_fkey" FOREIGN KEY ("id_исполнителя") REFERENCES public."Исполнители"(id);


--
-- Name: Альбомы_и_исполнители Альбомы_и_исполнители_id_альбома_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Альбомы_и_исполнители"
    ADD CONSTRAINT "Альбомы_и_исполнители_id_альбома_fkey" FOREIGN KEY ("id_альбома") REFERENCES public."Альбомы"(id);


--
-- Name: Жанры_и_исполнители Жанры_и_исполните_id_исполнителя_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Жанры_и_исполнители"
    ADD CONSTRAINT "Жанры_и_исполните_id_исполнителя_fkey" FOREIGN KEY ("id_исполнителя") REFERENCES public."Исполнители"(id);


--
-- Name: Жанры_и_исполнители Жанры_и_исполнители_id_жанра_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Жанры_и_исполнители"
    ADD CONSTRAINT "Жанры_и_исполнители_id_жанра_fkey" FOREIGN KEY ("id_жанра") REFERENCES public."Жанры"(id);


--
-- Name: Треки Треки_id_альбома_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Треки"
    ADD CONSTRAINT "Треки_id_альбома_fkey" FOREIGN KEY ("id_альбома") REFERENCES public."Альбомы"(id);


--
-- Name: Треки_в_сборнике Треки_в_сборнике_id_сборника_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Треки_в_сборнике"
    ADD CONSTRAINT "Треки_в_сборнике_id_сборника_fkey" FOREIGN KEY ("id_сборника") REFERENCES public."Сборники"(id);


--
-- Name: Треки_в_сборнике Треки_в_сборнике_id_трека_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Треки_в_сборнике"
    ADD CONSTRAINT "Треки_в_сборнике_id_трека_fkey" FOREIGN KEY ("id_трека") REFERENCES public."Треки"(id);


--
-- PostgreSQL database dump complete
--

